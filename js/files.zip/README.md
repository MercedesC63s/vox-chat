# vox

A minimal, monochrome communication app: real-time texting and 1:1 voice calling, built with vanilla HTML/CSS/JS + WebRTC, hosted free on GitHub Pages, signaled through Firebase.

**This is stage 1**: accounts, 1:1 texting, 1:1 voice calling with a modern calling screen. Group chats, real "on-hold" signaling, chess, and the Christo Pissto drawing game are the next stages — the code is structured so they slot in without a rewrite (see *Roadmap* below).

---

## 1. Why Firebase is required

GitHub Pages only serves static files — it can't run a server. WebRTC calls still need a way for two browsers to exchange connection info before audio can flow directly between them (this is called *signaling*). Firebase Firestore plays that role here: it stores accounts, chat messages, and the temporary call-setup handshake. Once a call connects, audio flows peer-to-peer — Firebase isn't in the audio path at all.

## 2. Create your Firebase project (free tier is enough)

1. Go to [console.firebase.google.com](https://console.firebase.google.com) → **Add project** → name it (e.g. `vox-chat`) → finish the wizard.
2. **Build → Authentication → Get started → Email/Password → Enable → Save.**
3. **Build → Firestore Database → Create database → Start in production mode** (we'll paste in rules below) → pick any region.
4. **Project settings (gear icon) → General → Your apps → Web (`</>`)** → register an app (nickname anything, no need for hosting) → copy the `firebaseConfig` object it gives you.
5. Paste those values into `js/firebase-config.js` in this repo, replacing the `"PASTE_ME"` placeholders.

## 3. Lock it down with Firestore rules

In **Firestore Database → Rules**, replace the default with:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
    match /chats/{chatId} {
      allow read, write: if request.auth != null &&
        request.auth.uid in resource.data.participants;
      allow create: if request.auth != null &&
        request.auth.uid in request.resource.data.participants;
      match /messages/{messageId} {
        allow read, create: if request.auth != null;
      }
    }
    match /calls/{callId} {
      allow read, write: if request.auth != null;
      match /{sub}/{docId} {
        allow read, write: if request.auth != null;
      }
    }
  }
}
```

Click **Publish**.

## 4. Deploy to GitHub Pages

```bash
git init
git add .
git commit -m "vox: stage 1 — texting + 1:1 calling"
git branch -M main
git remote add origin https://github.com/<your-username>/vox-chat.git
git push -u origin main
```

Then on GitHub: **Settings → Pages → Source: Deploy from a branch → Branch: `main` / `(root)` → Save.**
Your app will be live at `https://<your-username>.github.io/vox-chat/` in a minute or two.

## 5. Try it

Open the live URL in two different browsers (or one normal + one incognito window), sign up two accounts, start a conversation from one account by entering the other's email, and hit the call button. Allow microphone access when prompted.

---

## How it's built

```
vox-chat/
├── index.html          all screens: auth, chat list, chat, incoming/active call
├── css/styles.css      design tokens — pure black/white, Space Grotesk + Inter + JetBrains Mono
└── js/
    ├── firebase-config.js   your project keys (edit this)
    ├── state.js             shared in-memory app state
    ├── auth.js               signup / login / logout
    ├── app.js                routing, chat list, "new conversation"
    ├── chat.js               real-time messages
    └── call.js               WebRTC signaling + calling screen + mute/hold/hangup
```

- **Signaling flow**: caller writes an `offer` to a `calls/{id}` document → callee's listener catches it (their UI shows the incoming-call screen with the ripple animation) → on accept, callee writes an `answer` back → both sides exchange ICE candidates through `callerCandidates` / `calleeCandidates` subcollections → once that handshake finishes, audio flows directly peer-to-peer over WebRTC, not through Firebase.
- **STUN only, no TURN**: works for most home/office networks. Calls behind strict corporate NATs may fail to connect — adding a TURN server (e.g. via [Twilio](https://www.twilio.com/docs/stun-turn) or [metered.ca](https://www.metered.ca/tools/openrelay/)) is a one-line addition to `ICE_SERVERS` in `call.js` when you're ready.

## Roadmap (stage 2+)

- **Group chats** — extend the `chats` doc's `participants` array past 2, and move calling to a mesh or SFU-based group call.
- **Real hold** — right now hold just mutes locally; a full version would write a `status: "hold"` field to the call doc so the peer's screen shows "they put you on hold."
- **Chess** — a two-player board synced the same way messages are, using a `moves` subcollection per game.
- **Christo Pissto** (draw & guess) — drop in as its own `games/christo-pissto/` route, reusing the same account/room system.
